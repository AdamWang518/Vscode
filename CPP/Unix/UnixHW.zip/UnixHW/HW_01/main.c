#include <stdio.h>

#include "HW_01.h"

int
main ()
{
	int a, b, c;
	int X;

	a = 10;
	b = 20;
	c = 30;
	X = calculate(a, b, c);

	printf("X = %d\n", X);
	return 0;
}




