from flask import Flask, request
import json
from linebot import LineBotApi, WebhookHandler
from linebot.exceptions import InvalidSignatureError
from linebot.models import MessageEvent, TextMessage, TextSendMessage, ImageSendMessage
import os

app = Flask(__name__)

access_token = 'm6xTCwdcun54gH0182O9XT0vpZ+nI+LCtC2OeCBBTSyQsG8f/GleNLPKgKdNUDQOIpT6oPuNPwxG4AqUPzxG6k12hsqz4Qzsr0lXMNsII28jYO7sE5ms8QbyqfERQbfpq8zyEePR9WWA+O+XNcLYJAdB04t89/1O/w1cDnyilFU='
secret = '027adcb0f2ae81e56a3f796e42f3d515'
line_bot_api = LineBotApi(access_token)
handler = WebhookHandler(secret)


@app.route("/", methods=['POST'])
def linebot():
    body = request.get_data(as_text=True)  # 取得收到的訊息內容
    try:
        json_data = json.loads(body)  # json 格式化訊息內容
        signature = request.headers['X-Line-Signature']  # 加入回傳的 headers
        handler.handle(body, signature)  # 綁定訊息回傳的相關資訊
        event = json_data['events'][0]  # 取得第一個事件
        tk = event['replyToken']  # 取得回傳訊息的 Token
        message_type = event['message']['type']  # 取得 LINE 收到的訊息類型

        if message_type == 'text':
            msg = event['message']['text']  # 取得 LINE 收到的文字訊息
            reply = msg
        elif message_type == 'image':
            msg_id = event['message']['id']  # 取得訊息 id
            message_content = line_bot_api.get_message_content(msg_id)  # 根據訊息 ID 取得訊息內容
            with open(f'{msg_id}.jpg', 'wb') as file:
                file.write(message_content.content)  # 以二進位的方式寫入檔案
            reply = '圖片儲存完成！'
            print(reply)
            line_bot_api.reply_message(tk, TextSendMessage(text=reply))  # 回傳訊息

            # 获取当前工作目录
            current_directory = os.getcwd()

            # 获取图片的绝对路径
            image_path = os.path.abspath(f'./{msg_id}.jpg')

            # 创建 ImageSendMessage 对象，并将本地图片发送回 LINE
            image_message = ImageSendMessage(
                original_content_url=image_path,
                preview_image_url=image_path
            )
            line_bot_api.reply_message(tk, image_message)

        else:
            reply = '你傳的不是文字或圖片呦～'

        print(reply)
        line_bot_api.reply_message(tk, TextSendMessage(text=reply))  # 回傳訊息
    except:
        print(body)

    return 'OK'


if __name__ == "__main__":
    app.run(port=5001)
